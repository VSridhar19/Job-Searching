package com.example.sridhar.job_searching;

import android.app.LoaderManager;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.Nullable;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Display_activity extends AppCompatActivity  implements LoaderManager.LoaderCallbacks<List<Data>>{
    RecyclerView recyclerView;
    int LOADER_ID = 1;
    ArrayList<Data> dataList;
    ProgressBar loadingIndicator;
    String num;
    String message = "Check Internet Connection";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_activity);
        recyclerView=findViewById(R.id.rec1);
        loadingIndicator = findViewById(R.id.indicator);
        num=getIntent().getStringExtra(MainActivity.Key);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if(connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState()== NetworkInfo.State.CONNECTED||
                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState()==NetworkInfo.State.CONNECTED) {
            getLoaderManager().initLoader(LOADER_ID, null,this);
        }else{
            AlertDialog.Builder builder =new AlertDialog.Builder(this);
            builder.setMessage(message).setCancelable(true);
            builder.show();
            finish();
        }
    }


    @Override
    public Loader<List<Data>> onCreateLoader(int i, Bundle bundle) {
        return new android.content.AsyncTaskLoader<List<Data>>(this
        ){
            List<Data> datalst = null;

            protected void onStartLoading() {
                if (datalst != null) {
                    deliverResult(datalst);
                } else {
                    loadingIndicator.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                    forceLoad();
                }

            }

            @Nullable
            public List<Data> loadInBackground() {
                URL url = JsonData.buildURl(num);
                try {
                    String json = JsonData.getResponse(url);
                    List<Data> data1 = JsonData.jsonParse(json);
                    return data1;
                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                } catch (JSONException e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            public void deliverResult(@Nullable List<Data> data) {
                datalst = data;
                super.deliverResult(data);
            }
        };
    }

            @Override
    public void onLoadFinished(Loader<List<Data>> loader, List<Data> data) {
                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                loadingIndicator.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
                Toast.makeText(this, ""+data.size(), Toast.LENGTH_SHORT).show();
                recyclerView.setAdapter(new Adapter(this,data));

    }

    @Override
    public void onLoaderReset(Loader<List<Data>> loader) {

    }
}
