package com.example.sridhar.job_searching;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import static android.os.Build.ID;

public class JsonData {
    public static final String url = "https://jobs.github.com/positions.json?location=new+york&";
    //  public static final String Location = "location";
    public static final String JSONARRAY = "array";
    public static final String ID = "id";
    public static final String tittle = "tittle";

    public static URL buildURl(String num) {
        Uri uri = Uri.parse(url).buildUpon().appendQueryParameter("description",num).build();
        URL newUrl = null;
        try {
            newUrl = new URL(uri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return newUrl;
    }

    public static String getResponse(URL url) throws IOException {
        HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
        try {
            InputStream in = urlConnection.getInputStream();

            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("\\A");

            boolean hasInput = scanner.hasNext();
            if (hasInput) {
                return scanner.next();
            } else {
                return null;
            }
        } finally {
            urlConnection.disconnect();
        }
    }

    public static List<Data> jsonParse(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        List<Data> list = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            Data data = new Data();
            // JSONArray jsonArray1 = jsonObject.getJSONArray(String.valueOf(i));
            data.setDesc(jsonObject.getString("location"));
           // data.setId(jsonObject1.get("id"));
            data.setTittle(jsonObject.getString("title"));
            //data.getLocation(jsonObject1.getString())
            list.add(data);
        }

        return list;
    }
}