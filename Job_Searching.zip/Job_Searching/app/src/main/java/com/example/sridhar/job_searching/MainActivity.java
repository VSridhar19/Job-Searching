package com.example.sridhar.job_searching;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    Button button;
    public static final String Key = "name";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText=findViewById(R.id.e1);
        button=findViewById(R.id.b1);
    }

    public void search(View view) {
        if (editText.getText().toString().length()!=0) {
               String s=editText.getText().toString().trim();
                    Intent intent = new Intent(MainActivity.this, Display_activity.class);
                    intent.putExtra(Key,s);
            Toast.makeText(this, ""+s, Toast.LENGTH_SHORT).show();
                    startActivity(intent);

        }else{
            Toast.makeText(this, "Please enter any technology", Toast.LENGTH_SHORT).show();
        }

    }
    }

